package com.carta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeGrantRepositoryImpl implements EmployeeGrantRepository {
    private final Map<EmployeeGrantID, EmployeeGrant> employeeGrants = new HashMap<>();

    @Override
    public EmployeeGrant get(EmployeeGrantID employeeGrantID) {
        EmployeeGrant employeeGrant = employeeGrants.get(employeeGrantID);
        if (employeeGrant != null) {
            return employeeGrant;
        }
        throw new RuntimeException();
    }

    @Override
    public EmployeeGrant getOrCreate(EmployeeGrantID employeeGrantID) {
        employeeGrants.putIfAbsent(employeeGrantID, new EmployeeGrant(employeeGrantID));
        return get(employeeGrantID);
    }

    @Override
    public List<EmployeeGrant> getAll() {
        return new ArrayList<>(employeeGrants.values());
    }

    @Override
    public void add(EmployeeGrant employeeGrant) {
        employeeGrants.put(employeeGrant.getEmployeeGrantID(), employeeGrant);
    }
}
