package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class EmployeeGrantCalculator {
    public Map<EmployeeGrantID, BigDecimal> calculate(LocalDate asOfDate, List<EmployeeGrant> employeeGrants) {
        return employeeGrants.stream()
                .collect(Collectors.toMap((EmployeeGrant::getEmployeeGrantID),
                (employeeGrant -> calculate(employeeGrant, asOfDate))
        ));
    }

    public BigDecimal calculate(EmployeeGrant employeeGrant, LocalDate asOfDate){

        VestingQuantity result = new VestingQuantity();
        result = processVestSchedules(employeeGrant.getVestSchedules(), asOfDate, result);
        result = processCancels(employeeGrant.getCancelActivities(), asOfDate, result);
        return result.getVestedQuantity();

    }

    private VestingQuantity processVestSchedules(TreeMap<LocalDate, BigDecimal> vestSchedules,
                                                 LocalDate asOfDate,
                                                 VestingQuantity result) {
        vestSchedules.forEach((vestDate, trancheQuantity) -> {
            if (vestDate.isAfter(asOfDate)) {
                result.addUnvestedQuantity(trancheQuantity);
            }else {
                result.addVestedQuantity(trancheQuantity);
            }
        });


        // TODo no side effect
        return result;

    }

    private VestingQuantity processCancels(List<CancelActivity> cancels, LocalDate asOfDate, VestingQuantity result) {
        cancels.forEach(activity ->{
            if (!activity.getDate().isAfter(asOfDate)){
                if ( result.getUnvestedQuantity().compareTo(activity.getAmount()) >=0){
                    result.minusUnvestedQuantity(activity.getAmount());
                }else{
                    BigDecimal stillToCancelAmount = activity.getAmount().subtract(result.getUnvestedQuantity());
                    result.minusUnvestedQuantity(result.getUnvestedQuantity());
                    result.minusVestedQuantity(stillToCancelAmount);
                }
            }
        });

        return result;



    }

}
