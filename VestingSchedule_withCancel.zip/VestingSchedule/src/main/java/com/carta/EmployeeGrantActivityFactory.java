package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeGrantActivityFactory {
    // TODO Fix me
    public void parse(EmployeeGrant employeeGrant,
                                       String type,
                                       LocalDate date,
                                       BigDecimal amount) {


        if (type.equals("VEST")) {
            employeeGrant.addVestTranche(date, amount);
        } else {
            employeeGrant.addCancel(date, amount);
        }
    }
}