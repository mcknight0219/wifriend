package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class EmployeeGrant {
    private EmployeeGrantID employeeGrantID;
    private final List<CancelActivity> cancelActivities = new ArrayList<>();
    private final TreeMap<LocalDate, BigDecimal> vestSchedules = new TreeMap<>();

    public EmployeeGrant(EmployeeGrantID id) {
        employeeGrantID = id;
    }

    public EmployeeGrantID getEmployeeGrantID() {
        return employeeGrantID;
    }

    public List<CancelActivity> getCancelActivities() {
        return cancelActivities;
    }

    public void addVestTranche(LocalDate date, BigDecimal amount) {
        vestSchedules.put(date, amount);
    }

    public void addCancel(LocalDate date, BigDecimal amount) {
        cancelActivities.add(new CancelActivity(date, amount));
    }

    public TreeMap<LocalDate, BigDecimal> getVestSchedules() {
        return vestSchedules;
    }
}
