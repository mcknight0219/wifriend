package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class EmployeeGrantActivityParser {
    public EmployeeGrantActivityParser(EmployeeRepository employeeRepository, EmployeeGrantRepository employeeGrantRepository, EmployeeGrantActivityFactory employeeGrantActivityParser) {
        this.employeeRepository = employeeRepository;
        this.employeeGrantRepository = employeeGrantRepository;
        this.employeeGrantActivityParser = employeeGrantActivityParser;
    }

    private final static int ACTIVITY_TYPE = 0;
    private final static int EMPLOYEE_ID = 1;
    private final static int EMPLOYEE_NAME = 2;
    private final static int AWARD_ID = 3;
    private final static int DATE = 4;
    private final static int AMOUNT = 5;

    private final EmployeeRepository employeeRepository;
    private final EmployeeGrantRepository employeeGrantRepository;
    private final EmployeeGrantActivityFactory employeeGrantActivityParser;

    public List<EmployeeGrant> parse(List<String[]> activities) {
        for (String[] activity : activities) {
            LocalDate date = LocalDate.parse(activity[DATE]);
            // TODO Fix me
            BigDecimal amount = BigDecimal.valueOf(Double.parseDouble(activity[AMOUNT]));
            EmployeeGrantActivityDto employeeGrantActivity = new EmployeeGrantActivityDto(activity[EMPLOYEE_ID],
                    activity[EMPLOYEE_NAME],
                    activity[AWARD_ID],
                    date,
                    amount);

            // TOOD Fix me
            Employee employee = employeeRepository.getOrCreate(employeeGrantActivity.getEmployeeID(), employeeGrantActivity.getEmployeeName());
            EmployeeGrantID eeGrantID = new EmployeeGrantID(activity[EMPLOYEE_ID], activity[AWARD_ID]);
            EmployeeGrant employeeGrant = employeeGrantRepository.getOrCreate(eeGrantID);

            employeeGrantActivityParser.parse(employeeGrant,
                    activity[ACTIVITY_TYPE],
                    date,
                    amount);
        }

        return employeeGrantRepository.getAll();
    }
}
