package com.carta;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.*;

class CancelActivityTest {
    private static BigDecimal TEST_AMOUNT = BigDecimal.valueOf(100);
    private static LocalDate TEST_DATE = LocalDate.of(2022, Month.JULY, 1);

    @Test
    public void calculateVestedShares_AfterAsAtDate_returnsZero() {
        CancelActivity testSubject = new CancelActivity(TEST_DATE.plusDays(3), TEST_AMOUNT);
        assertEquals(BigDecimal.ZERO, testSubject.calculateVestedShares(TEST_DATE));
    }

    @Test
    public void calculateVestedShares_beforeOrOnAsAtDate_returnsAmountNegated() {
        CancelActivity testSubject = new CancelActivity(TEST_DATE.minusDays(3), TEST_AMOUNT);
        assertEquals(TEST_AMOUNT.negate(), testSubject.calculateVestedShares(TEST_DATE));
    }
}