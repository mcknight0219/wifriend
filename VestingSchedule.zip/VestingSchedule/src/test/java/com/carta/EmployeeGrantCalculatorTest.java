package com.carta;

import com.carta.service.EmployeeGrantCalculator;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsMapContaining.hasKey;
import static org.junit.jupiter.api.Assertions.*;

class EmployeeGrantCalculatorTest {

    private EmployeeGrantCalculator _testSubject = new EmployeeGrantCalculator();
    private static final BigDecimal VEST_AMOUNT = BigDecimal.valueOf(100);
    private static final BigDecimal CANCEL_AMOUNT = BigDecimal.valueOf(50);
    private static final String EMPLOYEE_A = "Employee A";
    private static final String AWARD_A = "Award A";

    private static LocalDate TARGET_DATE = LocalDate.of(2022, Month.JULY, 19);

    @Test
    public void calculate_givenEmptyActivityList_returnEmptyResult() {
        assertTrue(_testSubject.calculateAll(TARGET_DATE, new ArrayList<>()).isEmpty());
    }

    @Test
    public void calculate_givenActivityList_oneEmployeeGrant_returnResult() {

    }

    @Test
    public void calculate_givenTwoActivities_bothVested_returnCorrect() {

    }

    @Test
    public void calculate_givenTwoActivities_oneVest_oneNot_returnVestedOnly() {

    }

    @Test
    public void calculate_twoActivities_oneVest_oneCancel_beforeAsAtDate_returnRemainging() {

    }
}