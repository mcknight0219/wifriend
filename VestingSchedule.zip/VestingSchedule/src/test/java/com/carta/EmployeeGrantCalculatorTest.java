package com.carta;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsMapContaining.hasKey;
import static org.junit.jupiter.api.Assertions.*;

class EmployeeGrantCalculatorTest {

    private EmployeeGrantCalculator _testSubject = new EmployeeGrantCalculator();
    private static final BigDecimal VEST_AMOUNT = BigDecimal.valueOf(100);
    private static final BigDecimal CANCEL_AMOUNT = BigDecimal.valueOf(50);
    private static final String EMPLOYEE_A = "Employee A";
    private static final String AWARD_A = "Award A";

    private static LocalDate TARGET_DATE = LocalDate.of(2022, Month.JULY, 19);

    @Test
    public void calculate_givenEmptyActivityList_returnEmptyResult() {
        assertTrue(_testSubject.calculate(TARGET_DATE, new ArrayList<>()).isEmpty());
    }

    @Test
    public void calculate_givenActivityList_oneEmployeeGrant_returnResult() {
        EmployeeGrantActivity vestOne = new VestActivity(TARGET_DATE.minusDays(1), VEST_AMOUNT);
        EmployeeGrantID eeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(eeGrantID);
        employeeGrant.addActivity(vestOne);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculate(TARGET_DATE, Collections.singletonList(employeeGrant));
        assertThat(actual, hasEntry(eeGrantID, VEST_AMOUNT));
        assertEquals(1, actual.size());
    }

    @Test
    public void calculate_givenTwoActivities_bothVested_returnCorrect() {
        EmployeeGrantActivity vestedOne= new VestActivity(TARGET_DATE, VEST_AMOUNT);
        EmployeeGrantActivity vestedTwo = new VestActivity(TARGET_DATE.minusDays(1), VEST_AMOUNT);
        EmployeeGrantID eeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(eeGrantID);
        employeeGrant.addActivity(vestedOne);
        employeeGrant.addActivity(vestedTwo);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculate(TARGET_DATE, Collections.singletonList(employeeGrant));
        assertThat(actual, hasEntry(eeGrantID, VEST_AMOUNT.multiply(BigDecimal.valueOf(2))));
        assertEquals(1, actual.size());
    }

    @Test
    public void calculate_givenTwoActivities_oneVest_oneNot_returnVestedOnly() {
        EmployeeGrantActivity vested= new VestActivity(TARGET_DATE.minusDays(1), VEST_AMOUNT);
        EmployeeGrantActivity noeVested = new VestActivity(TARGET_DATE.plusDays(1), VEST_AMOUNT);
        EmployeeGrantID eeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(eeGrantID);
        employeeGrant.addActivity(vested);
        employeeGrant.addActivity(noeVested);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculate(TARGET_DATE, Collections.singletonList(employeeGrant));
        assertThat(actual, hasEntry(eeGrantID, VEST_AMOUNT));
        assertEquals(1, actual.size());
    }

    @Test
    public void calculate_twoActivities_oneVest_oneCancel_beforeAsAtDate_returnRemainging() {
        EmployeeGrantActivity vest = new VestActivity(TARGET_DATE.minusDays(5), VEST_AMOUNT);
        EmployeeGrantActivity cancel = new CancelActivity(TARGET_DATE.minusDays(1), CANCEL_AMOUNT);
        EmployeeGrantID eeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(eeGrantID);
        employeeGrant.addActivity(vest);
        employeeGrant.addActivity(cancel);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculate(TARGET_DATE, Collections.singletonList(employeeGrant));
        assertThat(actual, hasEntry(eeGrantID, VEST_AMOUNT.subtract(CANCEL_AMOUNT)));
        assertEquals(1, actual.size());
    }
}