package com.carta.service;

import com.carta.entity.Employee;
import com.carta.entity.EmployeeGrantID;
import com.carta.repository.EmployeeRepository;
import com.carta.repository.EmployeeRepositoryImpl;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

class EmployeeGrantVestReportTest {
    private static String EMPLOYEE_ID = "E001";
    private static String EMPLOYEE_NAME = "Alice Smith";
    private static String AWARD_ID_A = "ISO-001";
    private static String AWARD_ID_B = "ISO-002";
    private static BigDecimal VEST_AMOUNT_A = BigDecimal.valueOf(40.10);
    private static BigDecimal VEST_AMOUNT_B = BigDecimal.valueOf(20.6);
    private static int PRECISION = 0;
    @Test
    public void generateReport_truncateWithPrecision() {
        EmployeeRepository employeeRepository = mock(EmployeeRepositoryImpl.class);
        Employee employee = new Employee(EMPLOYEE_ID, EMPLOYEE_NAME);
        doReturn(employee).when(employeeRepository).get(EMPLOYEE_ID);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        EmployeeGrantVestReport report = new EmployeeGrantVestReport(employeeRepository, PRECISION, new PrintStream(out));

        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID_A);
        Map<EmployeeGrantID, BigDecimal> result = new HashMap<>();
        result.put(employeeGrantID, VEST_AMOUNT_A);

        report.generateReport(result);

        assertEquals("E001,Alice Smith,ISO-001,40", out.toString().trim());
    }

    @Test
    public void generateReport_sortedByEmployeeID() {
        EmployeeRepository employeeRepository = mock(EmployeeRepositoryImpl.class);
        Employee employee = new Employee(EMPLOYEE_ID, EMPLOYEE_NAME);
        doReturn(employee).when(employeeRepository).get(EMPLOYEE_ID);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        EmployeeGrantVestReport report = new EmployeeGrantVestReport(employeeRepository, PRECISION, new PrintStream(out));

        EmployeeGrantID employeeGrantIDA = new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID_A);
        EmployeeGrantID employeeGrantIDB = new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID_B);
        Map<EmployeeGrantID, BigDecimal> result = new HashMap<>();
        result.put(employeeGrantIDB, VEST_AMOUNT_B);
        result.put(employeeGrantIDA, VEST_AMOUNT_A);

        report.generateReport(result);

        assertEquals("E001,Alice Smith,ISO-001,40" +  System.getProperty("line.separator") +"E001,Alice Smith,ISO-002,20", out.toString().trim());
    }
}