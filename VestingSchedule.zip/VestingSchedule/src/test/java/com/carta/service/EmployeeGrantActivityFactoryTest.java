package com.carta.service;

import com.carta.entity.Cancel;
import com.carta.entity.Employee;
import com.carta.entity.Vest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeGrantActivityFactoryTest {

    @Test
    public void create_vestType_shouldCreateVestActivity() {
        EmployeeGrantActivityFactory factory = new EmployeeGrantActivityFactory();
        EmployeeGrantActivityDto dto = new EmployeeGrantActivityDto.Builder()
                .type("VEST")
                .build();

        assertTrue(factory.create(dto) instanceof Vest);
    }

    @Test
    public void create_cancelType_shouldCreateCancelActivity() {
        EmployeeGrantActivityFactory factory = new EmployeeGrantActivityFactory();
        EmployeeGrantActivityDto dto = new EmployeeGrantActivityDto.Builder()
                .type("CANCEL")
                .build();

        assertTrue(factory.create(dto) instanceof Cancel);
    }
}