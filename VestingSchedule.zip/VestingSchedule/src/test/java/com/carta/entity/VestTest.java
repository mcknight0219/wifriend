package com.carta.entity;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.*;

class VestTest {
    private static final LocalDate AS_AT_DATE = LocalDate.of(2022, Month.JULY, 20);
    private static final BigDecimal AMOUNT = BigDecimal.valueOf(100);

    @Test
    public void getAmount_vestBeforeAsAtDate_returnsAmountNegated() {
        EmployeeGrantActivity vest = new Vest(AS_AT_DATE.minusDays(3), AMOUNT);
        assertEquals(AMOUNT, vest.getAmount(AS_AT_DATE));
    }

    @Test
    public void getAmount_vestAfterAsAtDate_returnsZero() {
        EmployeeGrantActivity vest = new Vest(AS_AT_DATE.plusDays(3), AMOUNT);
        assertEquals(BigDecimal.ZERO, vest.getAmount(AS_AT_DATE));
    }

    @Test
    public void getAmount_vestOnAsAtDate_returnsAmountNegated() {
        EmployeeGrantActivity vest = new Vest(AS_AT_DATE, AMOUNT);
        assertEquals(AMOUNT, vest.getAmount(AS_AT_DATE));
    }

}