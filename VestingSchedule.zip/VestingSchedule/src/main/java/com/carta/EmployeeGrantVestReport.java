package com.carta;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class EmployeeGrantVestReport {

    private EmployeeRepository employeeRepository;
    private PrintStream out;

    public EmployeeGrantVestReport(EmployeeRepository employeeRepository, PrintStream out) {
        this.employeeRepository = employeeRepository;
        this.out = out;
    }

    public void generateReport(Map<EmployeeGrantID, BigDecimal> vestData) {

        List<EmployeeGrantID> sortedEmployeeGrantIDs = vestData.keySet()
                .stream()
                .sorted()
                .collect(Collectors.toList());

        List<List<String>> rows = new ArrayList<>();

        for (EmployeeGrantID employeeGrantID : sortedEmployeeGrantIDs) {
            BigDecimal vestedQuantity = vestData.get(employeeGrantID);

            List<String> row = new ArrayList<>();
            Employee employee = employeeRepository.get(employeeGrantID.getEmployeeID());
            row.add(employee.getEmployeeID());
            row.add(employee.getName());
            row.add(employeeGrantID.getAwardID());
            row.add(vestedQuantity.toString());

            rows.add(row);
        }


        rows.stream().map(list -> String.join(",", list)).forEach(out::println);
    }

}
