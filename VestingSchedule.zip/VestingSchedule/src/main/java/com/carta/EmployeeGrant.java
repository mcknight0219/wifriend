package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class EmployeeGrant {
    private EmployeeGrantID employeeGrantID;
    private final List<EmployeeGrantActivity> activities = new ArrayList<>();

    public EmployeeGrant(EmployeeGrantID id) {
        employeeGrantID = id;
    }

    public EmployeeGrantID getEmployeeGrantID() {
        return employeeGrantID;
    }

    public void addActivity(EmployeeGrantActivity employeeGrantActivity) {
        activities.add(employeeGrantActivity);
    }

    public List<EmployeeGrantActivity> getActivities() {
        return activities;
    }
}
