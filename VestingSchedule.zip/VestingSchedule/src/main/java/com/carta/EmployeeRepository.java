package com.carta;

public interface EmployeeRepository {
    Employee get(String id);
    Employee getOrCreate(String id, String name);
    void add(Employee employee);
}
