package com.carta;

public class Employee {
    private final String _employeeID;
    private final String _name;

    public Employee(String employeeID, String name) {
        _employeeID = employeeID;
        _name = name;
    }


    public String getEmployeeID() {
        return _employeeID;
    }

    public String getName() {
        return _name;
    }
}
