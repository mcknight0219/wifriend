package com.carta.service;

import com.carta.repository.EmployeeRepository;
import com.carta.entity.Employee;
import com.carta.entity.EmployeeGrantID;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EmployeeGrantVestReport {

    private final EmployeeRepository employeeRepository;
    private final PrintStream outStream;
    private final int precision;

    public EmployeeGrantVestReport(EmployeeRepository employeeRepository, int precision, PrintStream outStream) {
        this.employeeRepository = employeeRepository;
        this.outStream = outStream;
        this.precision = precision;
    }

    public void generateReport(Map<EmployeeGrantID, BigDecimal> vestData) {
        vestData.keySet()
                .stream()
                .sorted()
                .map(employeeGrantID -> {
                    BigDecimal vestedQuantity = vestData.get(employeeGrantID).setScale(precision, RoundingMode.DOWN);
                    Employee employee = employeeRepository.get(employeeGrantID.getEmployeeID());

                    List<String> row = new ArrayList<>();
                    row.add(employee.getEmployeeID());
                    row.add(employee.getName());
                    row.add(employeeGrantID.getAwardID());
                    row.add(vestedQuantity.toString());

                    return row;
                })
                .map(list -> String.join(",", list))
                .forEach(outStream::println);
    }

}
