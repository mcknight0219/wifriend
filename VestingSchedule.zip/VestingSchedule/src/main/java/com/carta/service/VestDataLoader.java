package com.carta.service;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class VestDataLoader {

    private final EmployeeGrantActivityParser employeeGrantActivityParser;

    public VestDataLoader(EmployeeGrantActivityParser employeeGrantActivityParser) {
        this.employeeGrantActivityParser = employeeGrantActivityParser;
    }

    public void loadFile(String filename) throws IOException {
        try (Reader reader = new FileReader(filename)) {
            try (CSVReader csvReader = new CSVReader(reader)) {
                String[] event;
                while ((event = csvReader.readNext()) != null) {
                    employeeGrantActivityParser.parse(event);
                }
            }
        }
    }
}
