package com.carta.service;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.VestingQuantity;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CancelHandler implements EmployeeGrantHandler {
    private EmployeeGrantHandler next;

    @Override
    public VestingQuantity handle(EmployeeGrant employeeGrant, LocalDate asAtDate, VestingQuantity vestingQuantity) {
        employeeGrant.getCancels()
                .stream()
                .filter(cancel -> !cancel.getDate().isAfter(asAtDate))
                .forEach(cancel -> {
                    if (vestingQuantity.getUnvestedQuantity().compareTo(cancel.getAmount()) >= 0) {
                        vestingQuantity.minusUnvestedQuantity(cancel.getAmount());
                    } else {
                        BigDecimal stillToCancelAmount = cancel.getAmount().subtract(vestingQuantity.getUnvestedQuantity());
                        vestingQuantity.minusUnvestedQuantity(vestingQuantity.getUnvestedQuantity());
                        vestingQuantity.minusVestedQuantity(stillToCancelAmount);
                    }

                });

        if (next != null) {
            return next.handle(employeeGrant, asAtDate, vestingQuantity);
        }
        return vestingQuantity;
    }

    @Override
    public void setNext(EmployeeGrantHandler nextHandler) {
        this.next = nextHandler;
    }
}
