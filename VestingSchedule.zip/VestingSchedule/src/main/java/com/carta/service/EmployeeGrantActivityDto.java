package com.carta.service;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeGrantActivityDto {
    private final String type;
    private final String employeeID;
    private final String employeeName;
    private final String award;
    private final LocalDate date;
    private final BigDecimal amount;

    public EmployeeGrantActivityDto(String type, String employeeID, String employeeName, String award, LocalDate date, BigDecimal amount) {
        this.type = type;
        this.employeeID = employeeID;
        this.employeeName = employeeName;
        this.award = award;
        this.date = date;
        this.amount = amount;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getAward() {
        return award;
    }

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public boolean isVest() {
        return type.equals("VEST");
    }

    public boolean isCancel() {
        return type.equals("CANCEL");
    }
}
