package com.carta.service;

import com.carta.entity.Cancel;
import com.carta.entity.EmployeeGrantActivity;
import com.carta.entity.Vest;

public class EmployeeGrantActivityFactory {

    public EmployeeGrantActivity create(EmployeeGrantActivityDto dto) {
        if (dto.isVest()) {
            return new Vest(dto.getDate(), dto.getAmount());
        } else {
            return new Cancel(dto.getDate(), dto.getAmount());
        }
    }
}
