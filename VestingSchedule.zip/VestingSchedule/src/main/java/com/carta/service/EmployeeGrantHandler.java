package com.carta.service;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.VestingQuantity;

import java.time.LocalDate;

public interface EmployeeGrantHandler {
    VestingQuantity handle(EmployeeGrant employeeGrant, LocalDate asAtDate, VestingQuantity vestingQuantity);
    void setNext(EmployeeGrantHandler nextHandler);
}
