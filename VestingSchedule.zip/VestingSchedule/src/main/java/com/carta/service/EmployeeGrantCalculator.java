package com.carta.service;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.EmployeeGrantID;
import com.carta.entity.VestingQuantity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeGrantCalculator {
    public Map<EmployeeGrantID, BigDecimal> calculateAll(LocalDate asAtDate, List<EmployeeGrant> employeeGrants) {
        return employeeGrants.stream()
                .collect(Collectors.toMap(
                        (EmployeeGrant::getEmployeeGrantID),
                        (employeeGrant -> calculate(asAtDate, employeeGrant))));
    }

    private BigDecimal calculate(LocalDate asAtDate, EmployeeGrant employeeGrant){
        EmployeeGrantHandler cancelHandler = new CancelHandler();
        EmployeeGrantHandler vestHandler = new VestScheduleHandler();
        vestHandler.setNext(cancelHandler);

        return vestHandler.handle(employeeGrant, asAtDate, new VestingQuantity()).getVestedQuantity();
    }
}
