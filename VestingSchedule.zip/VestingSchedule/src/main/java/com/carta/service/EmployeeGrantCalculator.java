package com.carta.service;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.EmployeeGrantActivity;
import com.carta.entity.EmployeeGrantID;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeGrantCalculator {
    public Map<EmployeeGrantID, BigDecimal> calculateAll(LocalDate asAtDate, List<EmployeeGrant> employeeGrants) {
        return employeeGrants.stream()
                .collect(Collectors.toMap(
                        (EmployeeGrant::getEmployeeGrantID),
                        (employeeGrant -> calculate(asAtDate, employeeGrant))));
    }

    private BigDecimal calculate(LocalDate asAtDate, EmployeeGrant employeeGrant){
        BigDecimal vestingQuantity = BigDecimal.ZERO;
        for (Map.Entry<LocalDate, EmployeeGrantActivity> entry : employeeGrant.getActivities().entrySet()) {
            vestingQuantity = vestingQuantity.add(entry.getValue().getAmount(asAtDate));
            if (vestingQuantity.compareTo(BigDecimal.ZERO) < 0) {
                throw new RuntimeException("Out of balance after cancel for employee grant: " + employeeGrant.getEmployeeGrantID());
            }
        }
        return vestingQuantity;
    }
}
