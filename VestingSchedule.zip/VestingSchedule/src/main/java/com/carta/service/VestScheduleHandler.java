package com.carta.service;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.VestingQuantity;

import java.time.LocalDate;

public class VestScheduleHandler implements EmployeeGrantHandler {
    private EmployeeGrantHandler next;

    public VestScheduleHandler() {}

    @Override
    public VestingQuantity handle(EmployeeGrant employeeGrant, LocalDate asAtDate, VestingQuantity vestingQuantity) {
        employeeGrant.getVestSchedules().forEach((vestDate, trancheQuantity) -> {
            if (vestDate.isAfter(asAtDate)) {
                vestingQuantity.addUnvestedQuantity(trancheQuantity);
            }else {
                vestingQuantity.addVestedQuantity(trancheQuantity);
            }
        });

        if (next != null) {
            return next.handle(employeeGrant, asAtDate, vestingQuantity);
        }
        return vestingQuantity;
    }

    @Override
    public void setNext(EmployeeGrantHandler nextHandler) {
        this.next = nextHandler;
    }
}
