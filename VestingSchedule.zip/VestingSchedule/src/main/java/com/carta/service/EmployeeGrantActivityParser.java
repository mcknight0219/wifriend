package com.carta.service;

import com.carta.repository.EmployeeGrantRepository;
import com.carta.repository.EmployeeRepository;
import com.carta.entity.Employee;
import com.carta.entity.EmployeeGrant;
import com.carta.entity.EmployeeGrantID;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public class EmployeeGrantActivityParser {
    public EmployeeGrantActivityParser(EmployeeRepository employeeRepository, EmployeeGrantRepository employeeGrantRepository, int precision) {
        this.employeeRepository = employeeRepository;
        this.employeeGrantRepository = employeeGrantRepository;
        this.precision = precision;
    }

    private final static int ACTIVITY_TYPE = 0;
    private final static int EMPLOYEE_ID = 1;
    private final static int EMPLOYEE_NAME = 2;
    private final static int AWARD_ID = 3;
    private final static int DATE = 4;
    private final static int AMOUNT = 5;

    private final EmployeeRepository employeeRepository;
    private final EmployeeGrantRepository employeeGrantRepository;
    private final int precision;

    public void parse(String[] activity) {
        LocalDate date = LocalDate.parse(activity[DATE]);
        BigDecimal amount = new BigDecimal(activity[AMOUNT]).setScale(precision, RoundingMode.DOWN);

        EmployeeGrantActivityDto employeeGrantActivity = new EmployeeGrantActivityDto(
                activity[ACTIVITY_TYPE],
                activity[EMPLOYEE_ID],
                activity[EMPLOYEE_NAME],
                activity[AWARD_ID],
                date,
                amount);

        Employee employee = employeeRepository.getOrCreate(employeeGrantActivity.getEmployeeID(), employeeGrantActivity.getEmployeeName());
        EmployeeGrantID eeGrantID = new EmployeeGrantID(employee.getEmployeeID(), employeeGrantActivity.getAward());
        EmployeeGrant employeeGrant = employeeGrantRepository.getOrCreate(eeGrantID);

        employeeGrant.addActivity(employeeGrantActivity);
    }
}
