package com.carta.repository;

import com.carta.entity.Employee;

import java.util.HashMap;
import java.util.Map;

public class EmployeeRepositoryImpl implements EmployeeRepository {
    private final Map<String, Employee> employees = new HashMap<>();

    @Override
    public Employee get(String id) {
        if (employees.containsKey(id)) {
            return employees.get(id);
        }
        throw new RuntimeException("Employee " + id + " doesn't exist");
    }

    @Override
    public Employee getOrCreate(String id, String name) {
        employees.putIfAbsent(id, new Employee(id, name));
        return get(id);
    }

}
