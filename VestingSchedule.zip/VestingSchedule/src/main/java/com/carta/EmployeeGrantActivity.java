package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;

public abstract class EmployeeGrantActivity {
    LocalDate date;
    BigDecimal amount;

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public abstract BigDecimal calculateVestedShares(LocalDate asOfDate);
}
