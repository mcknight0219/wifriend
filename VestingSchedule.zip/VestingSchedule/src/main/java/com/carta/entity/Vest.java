package com.carta.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Vest extends EmployeeGrantActivity {
    public Vest(LocalDate date, BigDecimal amount) {
        super(date, amount);
    }

    @Override
    public BigDecimal getAmount(LocalDate asAtDate) {
        if (!date.isAfter(asAtDate)) {
            return amount;
        }
        return BigDecimal.ZERO;
    }
}
