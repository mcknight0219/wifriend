package com.carta.entity;

import java.time.LocalDate;
import java.util.TreeMap;

public class EmployeeGrant {
    private final EmployeeGrantID employeeGrantID;
    private final TreeMap<LocalDate, EmployeeGrantActivity> activities = new TreeMap<>();

    public EmployeeGrant(EmployeeGrantID id) {
        employeeGrantID = id;
    }

    public EmployeeGrantID getEmployeeGrantID() {
        return employeeGrantID;
    }

    public void addActivity(EmployeeGrantActivity activity) {
        activities.put(activity.getDate(), activity);
    }

    public TreeMap<LocalDate, EmployeeGrantActivity> getActivities() {
        return activities;
    }
}
