package com.carta.entity;

import com.carta.service.EmployeeGrantActivityDto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class EmployeeGrant {
    private final EmployeeGrantID employeeGrantID;
    private final List<Cancel> cancels = new ArrayList<>();
    private final TreeMap<LocalDate, BigDecimal> vestSchedules = new TreeMap<>();

    public EmployeeGrant(EmployeeGrantID id) {
        employeeGrantID = id;
    }

    public EmployeeGrantID getEmployeeGrantID() {
        return employeeGrantID;
    }

    public List<Cancel> getCancels() {
        return cancels;
    }

    private void addVestTranche(LocalDate date, BigDecimal amount) {
        vestSchedules.put(date, amount);
    }

    private void addCancel(LocalDate date, BigDecimal amount) {
        cancels.add(new Cancel(date, amount));
    }

    public TreeMap<LocalDate, BigDecimal> getVestSchedules() {
        return vestSchedules;
    }

    public void addActivity(EmployeeGrantActivityDto activity) {
        if (activity.isVest()) {
            addVestTranche(activity.getDate(), activity.getAmount());
        } else if (activity.isCancel()) {
            addCancel(activity.getDate(), activity.getAmount());
        }
    }
}
