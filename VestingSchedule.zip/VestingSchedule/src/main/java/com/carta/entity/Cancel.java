package com.carta.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Cancel {
    private final LocalDate date;
    private final BigDecimal amount;

    public Cancel(LocalDate date, BigDecimal amount) {
        this.date = date;
        this.amount = amount;
    }

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getAmount() {
        return amount;
    }
}
