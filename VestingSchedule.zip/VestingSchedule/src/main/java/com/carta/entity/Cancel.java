package com.carta.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Cancel extends EmployeeGrantActivity {
    public Cancel(LocalDate date, BigDecimal amount) {
        super(date, amount);
    }

    @Override
    public BigDecimal getAmount(LocalDate asAtDate) {
        if (!date.isAfter(asAtDate)) {
            return amount.negate();
        }
        return BigDecimal.ZERO;
    }
}
