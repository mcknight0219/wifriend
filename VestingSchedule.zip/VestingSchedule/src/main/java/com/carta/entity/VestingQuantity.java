package com.carta.entity;

import java.math.BigDecimal;

public class VestingQuantity {
    private BigDecimal vestedQuantity = BigDecimal.ZERO;
    private BigDecimal unvestedQuantity = BigDecimal.ZERO;

    public BigDecimal getVestedQuantity() {
        return vestedQuantity;
    }
    public BigDecimal getUnvestedQuantity() {
        return unvestedQuantity;
    }

    public void addVestedQuantity(BigDecimal value){
        vestedQuantity = vestedQuantity.add(value);
    }

    public void minusVestedQuantity(BigDecimal value){
        vestedQuantity = vestedQuantity.subtract(value);
    }

    public void addUnvestedQuantity(BigDecimal value){
        unvestedQuantity = unvestedQuantity.add(value);
    }

    public void minusUnvestedQuantity(BigDecimal value){
        unvestedQuantity = unvestedQuantity.subtract(value);
    }

}
