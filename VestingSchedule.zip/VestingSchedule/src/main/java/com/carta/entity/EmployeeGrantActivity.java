package com.carta.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

public abstract class EmployeeGrantActivity {
    final LocalDate date;
    final BigDecimal amount;

    public EmployeeGrantActivity(LocalDate date, BigDecimal amount) {
        this.date = date;
        this.amount = amount;
    }

    public LocalDate getDate() {
        return date;
    }
    public BigDecimal getAmount() { return amount; }
    public abstract BigDecimal getAmount(LocalDate asAtDate);
}
