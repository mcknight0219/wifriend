package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeGrantCalculator {
    public Map<EmployeeGrantID, BigDecimal> calculate(LocalDate asOfDate, List<EmployeeGrant> employeeGrants) {
        return employeeGrants.stream().collect(Collectors.toMap(
                (EmployeeGrant::getEmployeeGrantID),
                (employeeGrant -> employeeGrant.getActivities()
                        .stream()
                        .map(activity -> activity.calculateVestedShares(asOfDate))
                        .reduce(BigDecimal.ZERO, BigDecimal::add))
        ));
    }

}
