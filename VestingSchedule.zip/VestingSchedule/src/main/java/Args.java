import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Args {
    private String filename;
    private LocalDate asAtDate;
    private int precision = 0;

    public Args(String[] args) {
        parse(args);
    }

    private void parse(String[] args) throws IllegalArgumentException {
        if (args.length < 2) {
            throw new IllegalArgumentException("Missing arguments");
        }

        filename = args[0];
        try {
            asAtDate = LocalDate.parse(args[1]);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException(e);
        }

        if (args.length > 2) {
            try {
                precision = Integer.parseInt(args[2]);
            } catch(NumberFormatException e) {
                throw new IllegalArgumentException(e);
            }

            if (precision < 0 || precision > 6) {
                throw new IllegalArgumentException("Precision must be an integer between 0 and 6 inclusive");
            }
        }
    }

    public String getFilename() {
        return filename;
    }

    public LocalDate getAsAtDate() {
        return asAtDate;
    }

    public int getPrecision() {
        return precision;
    }
}
