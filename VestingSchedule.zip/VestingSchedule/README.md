# Vesting Program

## How to Build and Run
To build and run the program, you need to have JDK 1.8+ installed on your machine.
The program is a gradle based project.

- Build. Run following command in the root folder of project
  
  ```./gradlew build```

- Run.
  
  1.Run program with parameters `example.csv` and `2021-01-01`
  
  ```./gradlew run --args "example.csv 2021-01-01"```

  2.Run program with extra precision parameters

  ```./gradlew run --args "example.csv 2021-01-01 2"```

## Design

-  

## Assumptions

- The biggest assumption is the correctness of input content. For example,
  the format of the csv file, the date string, and number string are assumed
  to be valid.
  
- Assume cancel would firstly try to cancel un-vested shares in LIFO fashion.
  If there isn't any or enough, then try to cancel the vested (at as date
  of cancel date).
  

## Further Improvement

With no time constraint, the following improvement can be made:

- Validation on input data. Currently, we assume the correctness of
  input data in both format and data (such as date and number).
  
- Model vesting tranche, so it is easier for extension of more kinds
  of activities on shares, for example forfeiture, dividends, etc.
  
- Refactor on reporting functionality to make it more versatile and 
  easier to extend. For example, make sorting more flexible and extendable
  
- More test coverage.