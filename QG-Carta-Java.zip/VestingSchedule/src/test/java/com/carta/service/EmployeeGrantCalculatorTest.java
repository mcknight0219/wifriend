package com.carta.service;

import com.carta.entity.*;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsMapContaining.hasKey;
import static org.junit.jupiter.api.Assertions.*;

class EmployeeGrantCalculatorTest {

    private EmployeeGrantCalculator _testSubject = new EmployeeGrantCalculator();
    private static final BigDecimal VEST_AMOUNT_A = BigDecimal.valueOf(100);
    private static final BigDecimal VEST_AMOUNT_B = BigDecimal.valueOf(30);
    private static final BigDecimal CANCEL_AMOUNT = BigDecimal.valueOf(50);
    private static final String EMPLOYEE_A = "Employee A";
    private static final String AWARD_A = "Award A";

    private static LocalDate TARGET_DATE = LocalDate.of(2022, Month.JULY, 19);

    @Test
    public void calculate_givenEmptyActivityList_returnEmptyResult() {
        assertTrue(_testSubject.calculateAll(TARGET_DATE, new ArrayList<>()).isEmpty());
    }

    @Test
    public void calculate_oneEmployeeGrant_oneVested_returnResult() {
        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(employeeGrantID);
        EmployeeGrantActivity vested = new Vest(TARGET_DATE.minusDays(3), VEST_AMOUNT_A);
        employeeGrant.addActivity(vested);

        List<EmployeeGrant> employeeGrants = new ArrayList<>();
        employeeGrants.add(employeeGrant);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculateAll(TARGET_DATE, employeeGrants);
        assertEquals(VEST_AMOUNT_A, actual.get(employeeGrantID));
    }

    @Test
    public void calculate_oneEmployeeGrant_bothVested_returnSum() {
        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(employeeGrantID);
        EmployeeGrantActivity vestedA = new Vest(TARGET_DATE.minusDays(3), VEST_AMOUNT_A);
        EmployeeGrantActivity vestedB = new Vest(TARGET_DATE.minusDays(2), VEST_AMOUNT_B);
        employeeGrant.addActivity(vestedA);
        employeeGrant.addActivity(vestedB);

        List<EmployeeGrant> employeeGrants = new ArrayList<>();
        employeeGrants.add(employeeGrant);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculateAll(TARGET_DATE, employeeGrants);
        assertEquals(VEST_AMOUNT_A.add(VEST_AMOUNT_B), actual.get(employeeGrantID));
    }

    @Test
    public void calculate_givenTwoActivities_oneVest_oneNot_returnVestedOnly() {
        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(employeeGrantID);
        EmployeeGrantActivity vestedA = new Vest(TARGET_DATE.minusDays(3), VEST_AMOUNT_A);
        EmployeeGrantActivity vestedB = new Vest(TARGET_DATE.plusDays(2), VEST_AMOUNT_B);
        employeeGrant.addActivity(vestedA);
        employeeGrant.addActivity(vestedB);

        List<EmployeeGrant> employeeGrants = new ArrayList<>();
        employeeGrants.add(employeeGrant);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculateAll(TARGET_DATE, employeeGrants);
        assertEquals(VEST_AMOUNT_A, actual.get(employeeGrantID));
    }

    @Test
    public void calculate_twoActivities_oneVest_oneCancel_beforeAsAtDate_returnRemainging() {
        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(employeeGrantID);
        EmployeeGrantActivity vested = new Vest(TARGET_DATE.minusDays(3), VEST_AMOUNT_A);
        EmployeeGrantActivity cancel = new Cancel(TARGET_DATE.minusDays(2), CANCEL_AMOUNT);
        employeeGrant.addActivity(vested);
        employeeGrant.addActivity(cancel);

        List<EmployeeGrant> employeeGrants = new ArrayList<>();
        employeeGrants.add(employeeGrant);

        Map<EmployeeGrantID, BigDecimal> actual = _testSubject.calculateAll(TARGET_DATE, employeeGrants);
        assertEquals(VEST_AMOUNT_A.subtract(CANCEL_AMOUNT), actual.get(employeeGrantID));
    }

    @Test
    public void calculate_twoActivities_oneVest_oneCancel_cancelMoreThanVested_throwException() {
        EmployeeGrantID employeeGrantID = new EmployeeGrantID(EMPLOYEE_A, AWARD_A);
        EmployeeGrant employeeGrant = new EmployeeGrant(employeeGrantID);
        EmployeeGrantActivity vested = new Vest(TARGET_DATE.minusDays(3), VEST_AMOUNT_A);
        EmployeeGrantActivity cancel = new Cancel(TARGET_DATE.minusDays(2), VEST_AMOUNT_A.add(BigDecimal.ONE));
        employeeGrant.addActivity(vested);
        employeeGrant.addActivity(cancel);

        List<EmployeeGrant> employeeGrants = new ArrayList<>();
        employeeGrants.add(employeeGrant);

        assertThrows(RuntimeException.class, () -> _testSubject.calculateAll(TARGET_DATE, employeeGrants));
    }
}