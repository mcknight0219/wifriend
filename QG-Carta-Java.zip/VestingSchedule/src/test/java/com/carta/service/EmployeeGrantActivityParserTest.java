package com.carta.service;

import com.carta.entity.*;
import com.carta.repository.EmployeeGrantRepository;
import com.carta.repository.EmployeeGrantRepositoryImpl;
import com.carta.repository.EmployeeRepository;
import com.carta.repository.EmployeeRepositoryImpl;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class EmployeeGrantActivityParserTest {

    private static String EMPLOYEE_ID = "E001";
    private static String EMPLOYEE_NAME = "Alice Smith";
    private static String AWARD_ID = "ISO-001";
    private static String EVENT_DATE = "2022-07-20";
    private static String VEST_AMOUNT = "100.20";
    private static String CANCEL_AMOUNT = "30.11";
    private static int DEFAULT_PRECISION = 2;
    private static int PRECISION = 1;

    @Test
    public void parse_withVestingEvent_shouldAddToEmployeeGrant() {
        String[] event = new String[]{"VEST", EMPLOYEE_ID, EMPLOYEE_NAME, AWARD_ID, EVENT_DATE, VEST_AMOUNT};

        EmployeeRepository employeeRepository = new EmployeeRepositoryImpl();
        EmployeeGrantRepository employeeGrantRepository = new EmployeeGrantRepositoryImpl();

        EmployeeGrantActivityParser testSubject = new EmployeeGrantActivityParser(employeeRepository, employeeGrantRepository, new EmployeeGrantActivityFactory(), DEFAULT_PRECISION);
        testSubject.parse(event);

        EmployeeGrant actual = employeeGrantRepository.get(new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID));
        assertNotNull(actual);
        assertEquals(1, actual.getActivities().size());
        EmployeeGrantActivity activity = actual.getActivities().get(LocalDate.parse(EVENT_DATE));
        assertTrue(activity instanceof Vest);
        assertEquals(new BigDecimal(VEST_AMOUNT), activity.getAmount());
    }

    @Test
    public void parse_withCancelEvent_shouldAddToEmployeeGrant() {
        String[] event = new String[]{"CANCEL", EMPLOYEE_ID, EMPLOYEE_NAME, AWARD_ID, EVENT_DATE, CANCEL_AMOUNT};

        EmployeeRepository employeeRepository = new EmployeeRepositoryImpl();
        EmployeeGrantRepository employeeGrantRepository = new EmployeeGrantRepositoryImpl();

        EmployeeGrantActivityParser testSubject = new EmployeeGrantActivityParser(employeeRepository, employeeGrantRepository, new EmployeeGrantActivityFactory(), DEFAULT_PRECISION);
        testSubject.parse(event);

        EmployeeGrant actual = employeeGrantRepository.get(new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID));
        assertNotNull(actual);
        assertEquals(1, actual.getActivities().size());
        EmployeeGrantActivity activity = actual.getActivities().get(LocalDate.parse(EVENT_DATE));
        assertTrue(activity instanceof Cancel);
        assertEquals(new BigDecimal(CANCEL_AMOUNT), activity.getAmount());
    }

    @Test
    public void parse_truncateAmountToPrecision() {
        String[] event = new String[]{"VEST", EMPLOYEE_ID, EMPLOYEE_NAME, AWARD_ID, EVENT_DATE, VEST_AMOUNT};
        EmployeeRepository employeeRepository = new EmployeeRepositoryImpl();
        EmployeeGrantRepository employeeGrantRepository = new EmployeeGrantRepositoryImpl();

        EmployeeGrantActivityParser testSubject = new EmployeeGrantActivityParser(employeeRepository, employeeGrantRepository, new EmployeeGrantActivityFactory(), PRECISION);
        testSubject.parse(event);

        EmployeeGrant actual = employeeGrantRepository.get(new EmployeeGrantID(EMPLOYEE_ID, AWARD_ID));
        EmployeeGrantActivity activity = actual.getActivities().get(LocalDate.parse(EVENT_DATE));
        assertEquals(new BigDecimal(VEST_AMOUNT).setScale(PRECISION), activity.getAmount());
    }
}