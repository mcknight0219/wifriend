import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ArgsTest {
    private final static String FILENAME = "A.csv";
    private final static LocalDate AS_AT_DATE = LocalDate.of(2022, Month.JULY, 1);
    private final static int PRECISION = 3;
    @Test
    public void happyPath_shouldSetAllFields() {
        String[] args = new String[]{"A.csv", "2022-07-01", "3"};
        Args arg = new Args(args);
        assertEquals(FILENAME, arg.getFilename());
        assertEquals(AS_AT_DATE, arg.getAsAtDate());
        assertEquals(PRECISION, arg.getPrecision());
    }

    @Test
    public void oneArgument_shouldException() {
        String[] args = new String[]{"A"};
        assertThrows(IllegalArgumentException.class, () -> new Args(args));
    }

    @Test
    public void dateWrongFormat_shouldThrowException() {
        String[] args = new String[]{"A", "2022-01-001"};
        assertThrows(IllegalArgumentException.class, () -> new Args(args));
    }

    @Test
    public void precision_notInRange_shouldThrowException() {
        String[] args = new String[]{"A", "2022-01-01", "9"};
        assertThrows(IllegalArgumentException.class, () -> new Args(args));
    }
}