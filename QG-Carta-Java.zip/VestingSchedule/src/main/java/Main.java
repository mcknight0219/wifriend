import com.carta.entity.EmployeeGrantID;
import com.carta.repository.EmployeeGrantRepository;
import com.carta.repository.EmployeeGrantRepositoryImpl;
import com.carta.repository.EmployeeRepository;
import com.carta.repository.EmployeeRepositoryImpl;
import com.carta.service.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        try {
            new Main().run(new Args(args));
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.err.println("\nUsage: vesting_program csv_filename as_at_date [precision]\n");
        }
    }

    private void run(Args args) {
        EmployeeRepository employeeRepository = new EmployeeRepositoryImpl();
        EmployeeGrantRepository employeeGrantRepository = new EmployeeGrantRepositoryImpl();

        VestDataLoader loader = new VestDataLoader(
                new EmployeeGrantActivityParser(employeeRepository,
                                                employeeGrantRepository,
                                                new EmployeeGrantActivityFactory(),
                                                args.getPrecision()));

        try {
            loader.loadFile(args.getFilename());
        } catch (IOException e) {
            System.err.println(e.getMessage());
            return;
        }

        EmployeeGrantCalculator calculator = new EmployeeGrantCalculator();
        Map<EmployeeGrantID, BigDecimal> result = calculator.calculateAll(args.getAsAtDate(), employeeGrantRepository.getAll());

        EmployeeGrantVestReport report = new EmployeeGrantVestReport(employeeRepository, args.getPrecision(), System.out);
        report.generateReport(result);
    }
}
