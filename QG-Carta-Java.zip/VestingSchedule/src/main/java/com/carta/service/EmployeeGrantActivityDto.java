package com.carta.service;

import com.carta.entity.EmployeeGrantActivity;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeGrantActivityDto {
    private final String type;
    private final String employeeID;
    private final String employeeName;
    private final String award;
    private final LocalDate date;
    private final BigDecimal amount;

    public EmployeeGrantActivityDto(String type, String employeeID, String employeeName, String award, LocalDate date, BigDecimal amount) {
        this.type = type;
        this.employeeID = employeeID;
        this.employeeName = employeeName;
        this.award = award;
        this.date = date;
        this.amount = amount;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getAward() {
        return award;
    }

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public boolean isVest() {
        return type.equals("VEST");
    }

    public boolean isCancel() {
        return type.equals("CANCEL");
    }

    public static class Builder {
        private String type;
        private String employeeID;
        private String employeeName;
        private String award;
        private LocalDate date;
        private BigDecimal amount;

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder employeeID(String employeeID) {
            this.employeeID = employeeID;
            return this;
        }

        public Builder employeeName(String employeeName) {
            this.employeeName = employeeName;
            return this;
        }

        public Builder award(String award) {
            this.award = award;
            return this;
        }

        public Builder date(LocalDate date) {
            this.date = date;
            return this;
        }

        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        public EmployeeGrantActivityDto build() {
            EmployeeGrantActivityDto dto = new EmployeeGrantActivityDto(type, employeeID, employeeName, award, date, amount);
            return dto;
        }
    }
}
