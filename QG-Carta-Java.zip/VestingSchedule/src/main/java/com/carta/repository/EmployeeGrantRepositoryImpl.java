package com.carta.repository;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.EmployeeGrantID;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeGrantRepositoryImpl implements EmployeeGrantRepository {
    private final Map<EmployeeGrantID, EmployeeGrant> employeeGrants = new HashMap<>();

    @Override
    public EmployeeGrant get(EmployeeGrantID employeeGrantID) {
        EmployeeGrant employeeGrant = employeeGrants.get(employeeGrantID);
        if (employeeGrant != null) {
            return employeeGrant;
        }
        throw new RuntimeException("Employee Grant " + employeeGrantID + " doesn't exit");
    }

    @Override
    public EmployeeGrant getOrCreate(EmployeeGrantID employeeGrantID) {
        employeeGrants.putIfAbsent(employeeGrantID, new EmployeeGrant(employeeGrantID));
        return get(employeeGrantID);
    }

    @Override
    public List<EmployeeGrant> getAll() {
        return new ArrayList<>(employeeGrants.values());
    }

}
