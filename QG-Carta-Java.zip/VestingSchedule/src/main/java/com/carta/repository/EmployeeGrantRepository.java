package com.carta.repository;

import com.carta.entity.EmployeeGrant;
import com.carta.entity.EmployeeGrantID;

import java.util.List;

public interface EmployeeGrantRepository {
    EmployeeGrant get(EmployeeGrantID employeeGrantID);
    EmployeeGrant getOrCreate(EmployeeGrantID employeeGrantID);
    List<EmployeeGrant> getAll();
}
