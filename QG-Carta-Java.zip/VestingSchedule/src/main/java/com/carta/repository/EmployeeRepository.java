package com.carta.repository;

import com.carta.entity.Employee;

public interface EmployeeRepository {
    Employee get(String id);
    Employee getOrCreate(String id, String name);
}
