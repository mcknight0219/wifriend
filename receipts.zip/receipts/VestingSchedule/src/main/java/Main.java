import com.carta.*;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        if (args.length != 3) {
            throw new RuntimeException();
        }
        String filename = args[1];
        LocalDate asOfDate = null;
        try {
             asOfDate = LocalDate.parse(args[2]);
        } catch (DateTimeParseException e) {
        }

        List<EmployeeGrant> eeGrants = new ArrayList<>();
        EmployeeRepositoryImpl employeeRepository = new EmployeeRepositoryImpl();
        EmployeeGrantActivityParser activityParser = new EmployeeGrantActivityParser(employeeRepository,
                new EmployeeGrantRepositoryImpl(),
                new EmployeeGrantActivityFactory());

        try (Reader reader = new FileReader(filename)) {
            try (CSVReader csvReader = new CSVReader(reader)) {
                List<String[]> vestingEvents = csvReader.readAll();
                eeGrants.addAll(activityParser.parse(vestingEvents));
            }
        } catch (IOException e) {
        }

        EmployeeGrantCalculator calculator = new EmployeeGrantCalculator();
        Map<EmployeeGrantID, BigDecimal> result = calculator.calculate(asOfDate, eeGrants);

        EmployeeGrantVestReport report = new EmployeeGrantVestReport(employeeRepository, System.out);
        report.generateReport(result);
    }
}
