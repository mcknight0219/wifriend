package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeGrantActivityFactory {
    // TODO Fix me
    public EmployeeGrantActivity create(String type, LocalDate date, BigDecimal amount) {
        if (type.equals("VEST")) {
            return new VestActivity(date, amount);
        } else {
            return new CancelActivity(date, amount);
        }
    }
}