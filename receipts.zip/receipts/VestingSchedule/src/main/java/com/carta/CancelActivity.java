package com.carta;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CancelActivity extends EmployeeGrantActivity {
    public CancelActivity(LocalDate date, BigDecimal amount) {
        this.date = date;
        this.amount = amount;
    }

    @Override
    public BigDecimal calculateVestedShares(LocalDate asOfDate) {
            if (!asOfDate.isBefore(date)){
                return  amount.negate();
            }

            return BigDecimal.ZERO;
    }
}
