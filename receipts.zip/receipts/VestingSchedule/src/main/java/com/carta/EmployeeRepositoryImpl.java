package com.carta;

import java.util.HashMap;
import java.util.Map;

public class EmployeeRepositoryImpl implements EmployeeRepository {
    private Map<String, Employee> employees = new HashMap<>();

    @Override
    public Employee get(String id) {
        if (employees.containsKey(id)) {
            return employees.get(id);
        }
        throw new RuntimeException("Employee with id " + id + " doesn't exist");
    }

    @Override
    public Employee getOrCreate(String id, String name) {
        return null;
    }

    @Override
    public void add(Employee employee) {
        employees.put(employee.getEmployeeID(), employee);
    }
}
