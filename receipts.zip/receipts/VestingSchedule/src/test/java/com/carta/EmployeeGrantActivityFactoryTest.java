package com.carta;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeGrantActivityFactoryTest {

    private static String VEST_TYPE = "VEST";
    private static String CANCEL_TYPE = "CANCEL";

    private static LocalDate TEST_DATE = LocalDate.of(2022, Month.JULY, 1);
    private static BigDecimal TEST_AMOUNT = BigDecimal.valueOf(100);

    @Test
    public void create_givenActivityType_createCorrectActivity() {
        EmployeeGrantActivityFactory testSubject = new EmployeeGrantActivityFactory();
        assertTrue(testSubject.create(VEST_TYPE, TEST_DATE, TEST_AMOUNT) instanceof VestActivity);
        assertTrue(testSubject.create(CANCEL_TYPE, TEST_DATE, TEST_AMOUNT) instanceof CancelActivity);
    }
}