package com.carta;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.*;

public class EmployeeGrantVestReport {

    private EmployeeRepository employeeRepository;
    private PrintStream out;

    public EmployeeGrantVestReport(EmployeeRepository employeeRepository, PrintStream out) {
        this.employeeRepository = employeeRepository;
        this.out = out;
    }

    public void generateReport(Map<EmployeeGrantID, BigDecimal> vestData) {
        List<List<String>> rows = new ArrayList<>();
        for (Map.Entry<EmployeeGrantID, BigDecimal> entry : vestData.entrySet()) {
            List<String> row = new ArrayList<>();
            EmployeeGrantID eeID = entry.getKey();
            Employee employee = employeeRepository.get(eeID.getEmployeeID());
            row.add(employee.getEmployeeID());
            row.add(employee.getName());
            row.add(eeID.getAwardID());
            row.add(entry.getValue().toString());

            rows.add(row);
        }

        // Sorting

        //
        rows.forEach(out::println);
    }

}
