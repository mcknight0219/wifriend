package com.carta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeGrantRepositoryImpl implements EmployeeGrantRepository {
    private final Map<EmployeeGrantID, EmployeeGrant> employeeGrants = new HashMap<>();

    @Override
    public EmployeeGrant get(EmployeeGrantID employeeGrantID) {
        EmployeeGrant employeeGrant = employeeGrants.get(employeeGrantID);
        if (employeeGrant != null) {
            return employeeGrant;
        }
        throw new RuntimeException();
    }

    @Override
    public EmployeeGrant getOrCreate(EmployeeGrantID employeeGrantID) {
        return null;
    }

    @Override
    public List<EmployeeGrant> getAll() {
        return null;
    }

    @Override
    public void add(EmployeeGrant employeeGrant) {
        employeeGrants.put(employeeGrant.getEmployeeGrantID(), employeeGrant);
    }
}
