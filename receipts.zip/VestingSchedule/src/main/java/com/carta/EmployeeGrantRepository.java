package com.carta;

import java.util.List;

public interface EmployeeGrantRepository {
    EmployeeGrant get(EmployeeGrantID employeeGrantID);
    EmployeeGrant getOrCreate(EmployeeGrantID employeeGrantID);
    List<EmployeeGrant> getAll();
    void add(EmployeeGrant employeeGrant);
}
