package com.carta;

import java.util.Objects;

public class EmployeeGrantID {
    private final String employeeID;
    private final String awardID;

    public String getEmployeeID() {
        return employeeID;
    }

    public String getAwardID() {
        return awardID;
    }

    public EmployeeGrantID(String employeeID, String awardID) {
        this.employeeID = employeeID;
        this.awardID = awardID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeGrantID that = (EmployeeGrantID) o;
        return employeeID.equals(that.employeeID) && awardID.equals(that.awardID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeID, awardID);
    }
}
